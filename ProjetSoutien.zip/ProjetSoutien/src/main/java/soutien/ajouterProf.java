package soutien;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/ajouterprof")
public class ajouterProf extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Vous êtes dans le servlet ajout prof");

        String[] matieres = request.getParameterValues("matieres");
        String emploi = request.getParameter("emploi");
        String nomPrenom = request.getParameter("nomPrenom");
        String salles = request.getParameter("salles");
        String telephone = request.getParameter("telephone");
        String adresse = request.getParameter("adresse");
        String niveau = request.getParameter("niveau");
        Connection conn = null;
        PreparedStatement statement = null;

        // Connexion à la base de données
        String jdbcUrl = "jdbc:mysql://localhost:3306/users";
        String dbUsername = "root";
        String dbPassword = "";

        try {
            // Chargement du pilote JDBC
            Class.forName("com.mysql.jdbc.Driver");

            // Connexion à la base de données
            conn = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword);

            String query = "INSERT INTO profs (matiere,nomPrenom, emploi, salles, telephone, adresse, niveau) VALUES (?, ?, ?, ?, ?, ?,?)";
            statement = conn.prepareStatement(query);

            // Définissez les valeurs des paramètres dans la requête SQL
            for (String matiere : matieres) {
                statement.setString(1, matiere);
                statement.setString(2, nomPrenom);
                statement.setString(3, emploi);
                statement.setString(4, salles);
                statement.setString(5, telephone);
                statement.setString(6, adresse);
                statement.setString(7, niveau);

                // Exécutez la requête SQL
                statement.executeUpdate();
            }

            // Redirection vers Confirmation.jsp si l'opération réussit
            response.sendRedirect("Confirmation.jsp");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Redirection vers error.jsp si une exception se produit
            response.sendRedirect("error.jsp");
        } finally {
            try {
                // Fermeture des ressources
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}