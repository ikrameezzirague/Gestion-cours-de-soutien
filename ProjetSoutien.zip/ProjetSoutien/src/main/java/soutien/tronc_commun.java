package soutien;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/formtr")
public class tronc_commun extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        System.out.println("tron commun");
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    
             String day = request.getParameter("daySelect1");
        String date = request.getParameter("dateInput1");
        String time = request.getParameter("timeInput1");
        String subject = request.getParameter("subjectSelect1");
        String teacher = request.getParameter("teacherSelect1");
        String room = request.getParameter("roomSelect1");

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Remplacez les informations de connexion par les vôtres
            String url = "jdbc:mysql://localhost:3306/users";
            String username = "root";
            String password = "";

            // Établir une connexion à la base de données
            connection = DriverManager.getConnection(url, username, password);

            String sql = "INSERT INTO tronc_commun (day, date, time, subject, teacher, room) VALUES (?, ?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, day);
            preparedStatement.setString(2, date);
            preparedStatement.setString(3, time);
            preparedStatement.setString(4, subject);
            preparedStatement.setString(5, teacher);
            preparedStatement.setString(6, room);

            // Exécuter la requête
            int rowsAffected = preparedStatement.executeUpdate();

            // Log pour débogage
            System.out.println("Rows affected: " + rowsAffected);

            // Redirection vers la page de confirmation ou d'erreur en fonction du résultat
            if (rowsAffected > 0) {
                response.sendRedirect("Confirmation.jsp");
            } else {
                response.sendRedirect("error.jsp");
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Logger l'erreur ou envoyer des messages d'erreur détaillés
        } finally {
            // Fermer les ressources
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Logger l'erreur ou envoyer des messages d'erreur détaillés
            }
        }
    }
}