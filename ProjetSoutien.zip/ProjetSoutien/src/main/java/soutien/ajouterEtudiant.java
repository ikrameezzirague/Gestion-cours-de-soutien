package soutien;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/A")
public class ajouterEtudiant extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Vous êtes dans le servlet d'ajout");

        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String telephone = request.getParameter("telephone");
        String adresse = request.getParameter("adresse");
        String niveau = request.getParameter("niveau");
        String matieres = request.getParameter("matieres"); // Nouvelle variable pour récupérer les matières

        Connection conn = null;
        PreparedStatement statement = null;

        // Connexion à la base de données
        String jdbcUrl = "jdbc:mysql://localhost:3306/users";
        String dbUsername = "root";
        String dbPassword = "";

        try {
            // Chargement du pilote JDBC
            Class.forName("com.mysql.jdbc.Driver");

            // Connexion à la base de données
            conn = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword);

            // Insertion des données dans la base de données
            String query = "INSERT INTO etudiants (nom, prenom, telephone, adresse, niveau, matieres) VALUES (?, ?, ?, ?, ?, ?)";
            statement = conn.prepareStatement(query);
            statement.setString(1, nom);
            statement.setString(2, prenom);
            statement.setString(3, telephone);
            statement.setString(4, adresse);
            statement.setString(5, niveau);
            statement.setString(6, matieres); // Ajout des matières
            statement.executeUpdate();

            response.sendRedirect("Confirmation.jsp");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Gérer les erreurs de la base de données
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Une erreur s'est produite lors de l'ajout de l'étudiant.");
        } finally {
            try {
                // Fermeture des ressources
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
