package soutien;

 public class EmploiData {

        private String day;
		private String date;
		private String time;
		private String subject;
		private String teacher;
		private String room;

		public void setDay(String day) {
            this.day = day;
        }

        public String getDay() {
			return day;
		}

		public String getDate() {
			return date;
		}

		public String getTime() {
			return time;
		}

		public String getSubject() {
			return subject;
		}

		public String getTeacher() {
			return teacher;
		}

		public String getRoom() {
			return room;
		}

		public void setDate(String date) {
            this.date = date;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public void setSubject(String subject) {
            this.subject = subject;
        }

        public void setTeacher(String teacher) {
            this.teacher = teacher;
        }

        public void setRoom(String room) {
            this.room = room;
        }}