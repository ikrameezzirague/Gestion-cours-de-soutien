package soutien;

public class Etudiant {
    private String nom;
    private String prenom;
    private String telephone;
    private String adresse;
    private String niveau;

    // Constructeur avec tous les champs
    public Etudiant(String nom, String prenom, String telephone, String adresse, String niveau) {
        this.nom = nom;
        this.prenom = prenom;
        this.telephone = telephone;
        this.adresse = adresse;
        this.niveau = niveau;
    }

   
}
