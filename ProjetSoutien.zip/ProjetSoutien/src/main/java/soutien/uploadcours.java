package soutien;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet("/Cours")
@MultipartConfig(maxFileSize = 1024 * 1024 * 5) 
public class uploadcours extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Configuration de la base de données
    private static final String DB_URL = "jdbc:mysql://localhost:3306/users";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String matiere = request.getParameter("matiere");
        String niveau = request.getParameter("niveau");
        Part filePart = request.getPart("coursFile");
        String nomFichier = request.getParameter("nomFichier");
        
        InputStream inputStream = null;
        Connection conn = null;
        PreparedStatement statement = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }

        try {
            inputStream = filePart.getInputStream();

            // Établissement de la connexion à la base de données
            conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);

            // Préparation de la requête SQL
            String sql = "INSERT INTO cours (matiere, niveau, fichier, nom_fichier) VALUES (?, ?, ?, ?)";
            statement = conn.prepareStatement(sql);
            statement.setString(1, matiere);
            statement.setString(2, niveau);
            statement.setBlob(3, inputStream);
            statement.setString(4, nomFichier);

            // Exécution de la requête
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                // Redirection vers la page confirmation1.jsp
                response.sendRedirect("confirmation1.jsp");
            } else {
                response.getWriter().println("Erreur lors du dépôt du cours.");
            }
        } catch (SQLException e) {
            response.getWriter().println("Erreur SQL : " + e.getMessage());
        } finally {
            // Fermeture des ressources
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}