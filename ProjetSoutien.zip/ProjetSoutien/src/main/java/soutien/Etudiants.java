package soutien;

import java.sql.*;

public class Etudiants {
    public static void main(String[] args) {
        // Étape 1 : Charger le pilote JDBC
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return;
        }

        // Étape 2 : Établir une connexion à la base de données
        Connection connection = null;
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/users", "root", "");
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        // Étape 3 : Créer une déclaration
        Statement statement = null;
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        // Étape 4 : Exécuter la requête
        ResultSet resultSet = null;
        try {
            resultSet = statement.executeQuery("SELECT COUNT(*) FROM etudiants");
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        // Étape 5 : Récupérer et afficher le résultat
        try {
            if (resultSet.next()) {
                int nombreEtudiants = resultSet.getInt(1);
                System.out.println("Nombre d'étudiants : " + nombreEtudiants);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        // Étape 6 : Fermer la connexion et les ressources
        try {
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
