package soutien;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/telecharger")
public class télécharger extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Variables de connexion à la base de données
        String DB_URL = "jdbc:mysql://localhost:3306/users";
        String DB_USERNAME = "root";
        String DB_PASSWORD = "";

        // Récupérer l'ID du cours à télécharger à partir des paramètres de requête
        int courseId = Integer.parseInt(request.getParameter("id"));

        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);

            // Sélectionner le cours spécifié par l'ID
            String sql = "SELECT fichier FROM cours WHERE id = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, courseId);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // Récupérer le fichier depuis la base de données
                byte[] fileData = resultSet.getBytes("fichier");

                // Configurer les en-têtes de la réponse
                response.setContentType("application/pdf");
                response.setContentLength(fileData.length);
                response.setHeader("Content-Disposition", "attachment; filename=cours.pdf");

                // Envoyer le fichier en tant que réponse
                OutputStream outputStream = response.getOutputStream();
                outputStream.write(fileData);
                outputStream.close();
            } else {
                response.getWriter().println("Le cours spécifié n'existe pas.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Erreur : " + e.getMessage());
        } finally {
            // Fermer la connexion dans le bloc finally
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}