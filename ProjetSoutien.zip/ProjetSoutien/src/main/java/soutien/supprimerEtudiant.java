package soutien;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/suppression")
public class supprimerEtudiant extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Vous êtes dans le servlet de supp");

        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String niveau = request.getParameter("niveau");
        Connection conn = null;
        
        PreparedStatement statement = null;

        // Connexion à la base de données
        String jdbcUrl = "jdbc:mysql://localhost:3306/users";
        String dbUsername = "root";
        String dbPassword = "";

        try {
            // Chargement du pilote JDBC
            Class.forName("com.mysql.jdbc.Driver");

            // Connexion à la base de données
            conn = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword);

         
                String sql = "DELETE FROM etudiants WHERE nom = ? AND prenom = ? AND niveau = ?";
                statement = conn.prepareStatement(sql);
                statement.setString(1, nom);
                statement.setString(2, prenom);
                statement.setString(3, niveau);

                // Exécuter la requête de suppression
                int rowsAffected = statement.executeUpdate();

                // Vérifier si des lignes ont été supprimées avec succès
                if (rowsAffected > 0) {
                    // L'étudiant a été supprimé avec succès
                    response.sendRedirect("Confirmation.jsp");
                } else {
                    // Aucun étudiant correspondant trouvé
                    response.sendRedirect("error.jsp");
                }
            } catch (SQLException e) {
                // Gérer les exceptions de la base de données
                e.printStackTrace();
                response.sendRedirect("error.jsp");
            } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }