package soutien;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/form3")
public class apic3 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        System.out.println("3apiiiiiiiiiiiiiiiiiiiic");
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        String submitButton = request.getParameter("submitForm3");
        if (submitButton != null) {
           
        }  
        String day = request.getParameter("daySelect3");
        String date = request.getParameter("dateInput3");
        String time = request.getParameter("timeInput3");
        String subject = request.getParameter("subjectSelect3");
        String teacher = request.getParameter("teacherSelect3");
        String room = request.getParameter("roomSelect3");

        // Appeler la méthode pour enregistrer les données dans la base de données
        boolean success = saveData(day, date, time, subject, teacher, room);

        // Redirection vers la page de confirmation ou d'erreur en fonction du résultat
        if (success) {
            response.sendRedirect("Confirmation.jsp");
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    private boolean saveData(String day, String date, String time, String subject, String teacher, String room) {
        boolean success = false;
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Remplacez les informations de connexion par les vôtres
            String url = "jdbc:mysql://localhost:3306/users";
            String username = "root";
            String password = "";

            // Établir une connexion à la base de données
            connection = DriverManager.getConnection(url, username, password);

            String sql = "INSERT INTO 3apic_table (day, date, time, subject, teacher, room) VALUES (?, ?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, day);
            preparedStatement.setString(2, date);
            preparedStatement.setString(3, time);
            preparedStatement.setString(4, subject);
            preparedStatement.setString(5, teacher);
            preparedStatement.setString(6, room);

            // Exécuter la requête
            int rowsAffected = preparedStatement.executeUpdate();

            // Vérifier si l'opération a réussi
            if (rowsAffected > 0) {
                success = true;
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Logger l'erreur ou envoyer des messages d'erreur détaillés
        } finally {
            // Fermer les ressources
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Logger l'erreur ou envoyer des messages d'erreur détaillés
            }
        }
        return success;
    }
}
