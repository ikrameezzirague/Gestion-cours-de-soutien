package soutien;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/emploidetemps")
public class primaire extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/users";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Récupérer les données du formulaire
        String day = request.getParameter("day");
        String date = request.getParameter("date");
        String time = request.getParameter("time");
        String subject = request.getParameter("subject");
        String teacher = request.getParameter("teacher");
        String salle = request.getParameter("salle");

        // Insérer les données dans la base de données
        boolean success = insertData(day, date, time, subject, teacher, salle);

        // Redirection en fonction du succès de l'insertion
        if (success) {
            response.sendRedirect("Confirmation.jsp");
        } else {
            response.sendRedirect("Error.jsp?message=Erreur lors de l'insertion des données.");
        }
    }

    private boolean insertData(String day, String date, String time, String subject, String teacher, String salle) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Charger le pilote JDBC
            Class.forName("com.mysql.jdbc.Driver");

            // Établir une connexion à la base de données
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

            // Préparer la requête SQL
            String sql = "INSERT INTO primaire (day, date, time, subject, teacher, salle) VALUES (?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, day);
            pstmt.setString(2, date);
            pstmt.setString(3, time);
            pstmt.setString(4, subject);
            pstmt.setString(5, teacher);
            pstmt.setString(6, salle);

            // Exécuter la requête
            int rowsAffected = pstmt.executeUpdate();

            // Vérifier si l'insertion a réussi
            return rowsAffected > 0;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Gérer l'exception correctement dans un environnement de production
            return false;
        } finally {
            // Fermer les ressources
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Gérer l'exception correctement dans un environnement de production
            }
        }
    }
}
