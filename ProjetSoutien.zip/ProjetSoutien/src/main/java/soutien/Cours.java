package soutien;

import java.sql.Timestamp;

public class Cours {
    private int id;
    private String nomFichier;
    private byte[] contenuPdf;
    private String nomProf;
    private Timestamp dateUpload;

    // Constructeur
    public Cours(int id, String nomFichier, byte[] contenuPdf, String nomProf, Timestamp dateUpload) {
        this.id = id;
        this.nomFichier = nomFichier;
        this.contenuPdf = contenuPdf;
        this.nomProf = nomProf;
        this.dateUpload = dateUpload;
    }

    public Cours(String string, String string2, String string3, String string4) {
		// TODO Auto-generated constructor stub
	}

	// Getters et setters (à adapter selon les besoins)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomFichier() {
        return nomFichier;
    }

    public void setNomFichier(String nomFichier) {
        this.nomFichier = nomFichier;
    }

    public byte[] getContenuPdf() {
        return contenuPdf;
    }

    public void setContenuPdf(byte[] contenuPdf) {
        this.contenuPdf = contenuPdf;
    }

    public String getNomProf() {
        return nomProf;
    }

    public void setNomProf(String nomProf) {
        this.nomProf = nomProf;
    }

    public Timestamp getDateUpload() {
        return dateUpload;
    }

    public void setDateUpload(Timestamp dateUpload) {
        this.dateUpload = dateUpload;
    }
}
