package soutien;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/payer")
public class payements extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String niveau = request.getParameter("niveau");
        String matieres = request.getParameter("matieres");
        String telephone = request.getParameter("telephone");
        String prix = request.getParameter("prix");
        String datePaiement = request.getParameter("datePaiement");
        String resteAPayer = request.getParameter("resteAPayer");

        // Vérifier que les champs obligatoires ne sont pas null ou vides
        if (nom == null || prenom == null || niveau == null || matieres == null || telephone == null || prix == null ||
                nom.isEmpty() || prenom.isEmpty() || niveau.isEmpty() || matieres.isEmpty() || telephone.isEmpty() || prix.isEmpty()) {
            // Rediriger vers une page d'erreur avec un message approprié
            response.sendRedirect("error.jsp?message=Veuillez%20remplir%20tous%20les%20champs%20obligatoires");
            return;
        }

        boolean aPaye = request.getParameter("aPaye") != null && request.getParameter("aPaye").equals("on");

        // Appeler une méthode pour insérer les données dans la base de données
        boolean insertionReussie = insererDansBaseDeDonnees(nom, prenom, niveau, matieres, telephone, prix, datePaiement, aPaye, resteAPayer);

        // Rediriger vers une page de confirmation ou une page d'erreur appropriée
        if (insertionReussie) {
            response.sendRedirect("Confirmation.jsp");
        } else {
            response.sendRedirect("error.jsp?message=Erreur%20lors%20de%20l'insertion%20dans%20la%20base%20de%20données");
        }
    }

    private boolean insererDansBaseDeDonnees(String nom, String prenom, String niveau, String matieres, String telephone,
                                             String prix, String datePaiement, boolean aPaye, String resteAPayer) {
        // Remplacez ces valeurs par les informations de votre base de données
        String url = "jdbc:mysql://localhost:3306/users";
        String utilisateurBD = "root";
        String motDePasseBD = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Erreur lors du chargement du pilote JDBC", e);
        }

        try (Connection connexion = DriverManager.getConnection(url, utilisateurBD, motDePasseBD)) {
            String sql = "INSERT INTO paiements (nom, prenom, niveau, matieres, telephone, prix, date_paiement, a_paye, reste_a_payer) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {
                // Vérifier si la valeur de "nom" est null et affecter une valeur par défaut si nécessaire
                preparedStatement.setString(1, (nom != null) ? nom : "");

                preparedStatement.setString(2, prenom);
                preparedStatement.setString(3, niveau);
                preparedStatement.setString(4, matieres);
                preparedStatement.setString(5, telephone);
                preparedStatement.setString(6, prix);
                preparedStatement.setString(7, datePaiement);
                preparedStatement.setBoolean(8, aPaye);
                preparedStatement.setString(9, resteAPayer);

                int rowsAffected = preparedStatement.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion des données dans la base de données", e);
        }
    }
}
