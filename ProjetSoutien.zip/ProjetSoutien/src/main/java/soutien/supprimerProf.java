package soutien;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/supprimerProf")
public class supprimerProf extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nomPrenom = request.getParameter("nomPrenom");
        String[] matieres = request.getParameterValues("matieres");
        String niveau = request.getParameter("niveau");

        System.out.println("suppression");

        Connection conn = null;
        PreparedStatement statement = null;

        // Connexion à la base de données
        String jdbcUrl = "jdbc:mysql://localhost:3306/users";
        String dbUsername = "root";
        String dbPassword = "";

        try {
            // Chargement du pilote JDBC
            Class.forName("com.mysql.jdbc.Driver");

            // Connexion à la base de données
            conn = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword);
            String sql = "DELETE FROM profs WHERE nomPrenom = ? AND matiere = ? AND niveau = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, nomPrenom);

            for (String matiere : matieres) {
                statement.setString(2, matiere);
                statement.setString(3, niveau);
                statement.executeUpdate();
            }

            // Vérifier si des lignes ont été supprimées avec succès
            int rowsAffected = statement.getUpdateCount();
            if (rowsAffected > 0) {
                // L'enseignant a été supprimé avec succès
                response.sendRedirect("Confirmation.jsp");
            } else {
                // Aucun enseignant correspondant trouvé
                response.sendRedirect("error.jsp");
            }
        } catch (SQLException e) {
            // Gérer les exceptions de la base de données
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // Fermer les ressources de base de données
            try {
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}