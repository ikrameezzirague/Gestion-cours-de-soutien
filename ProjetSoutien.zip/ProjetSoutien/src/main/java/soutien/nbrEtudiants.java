package soutien;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/nbrEtudiants")
public class nbrEtudiants extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
System.out.println("le nbrEtudiants");
       
        Connection conn = null;
        PreparedStatement statement = null;

        // Connexion à la base de données
        String jdbcUrl = "jdbc:mysql://localhost:3306/users";
        String dbUsername = "root";
        String dbPassword = "";

        try {
            // Chargement du pilote JDBC
            Class.forName("com.mysql.jdbc.Driver");

            // Connexion à la base de données
            conn = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword);

            // Insertion des données dans la base de données
            String  niveau = request.getParameter("niveau"); // Récupérez le niveau du formulaire
            String countUsersQuery = "SELECT COUNT(*) AS userCount FROM etudiants WHERE niveau = ?";


            try (PreparedStatement preparedStatement = conn.prepareStatement(countUsersQuery)) {
                preparedStatement.setString(1, niveau);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    int userCount = 0;
                    if (resultSet.next()) {
                        userCount = resultSet.getInt("userCount");
                    }

                    // Utilisation du nombre d'étudiants récupéré (affichage ou autre traitement)
                    System.out.println("Nombre d'étudiants pour le niveau " + niveau + ": " + userCount);

                    // Envoyer une réponse au client
                    response.setContentType("text/plain");
                    response.getWriter().write("Nombre d'étudiants pour le niveau " + niveau + ": " + userCount);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Gestion des erreurs SQL
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erreur lors de la récupération des données");
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}