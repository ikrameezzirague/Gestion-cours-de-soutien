package soutien;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/t")
public class recupererFichier extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/users";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);

            // Sélectionner tous les fichiers
            String sql = "SELECT * FROM cours";
            statement = conn.prepareStatement(sql);
            resultSet = statement.executeQuery();

            List<Course> courses = new ArrayList<>();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String niveau = resultSet.getString("niveau");
                String matiere = resultSet.getString("matiere");

                // Afficher dans la console pour vérification
                System.out.println("ID: " + id + ", Niveau: " + niveau + ", Matière: " + matiere);

                Course course = new Course();
                course.setId(id);
                course.setNiveau(niveau);
                course.setMatiere(matiere);

                courses.add(course);
            }

            // Fermez le resultSet après avoir récupéré les données
            resultSet.close();

            // Après avoir obtenu la liste des cours
            request.setAttribute("courses", courses);

            RequestDispatcher dispatcher = request.getRequestDispatcher("/courses.jsp");
            dispatcher.forward(request, response);
        } catch (ClassNotFoundException | SQLException | ServletException e) {
            e.printStackTrace();
            response.getWriter().println("Erreur : " + e.getMessage());
        } finally {
            // Fermez la connexion dans le bloc finally
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}