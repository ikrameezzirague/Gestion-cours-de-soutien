package soutien;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/inscriptionsss")
public class inscription extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Vous êtes dans le servlet inscription");

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String profession = request.getParameter("profession");

        Connection conn = null;
        PreparedStatement statement = null;

        // Connexion à la base de données
        String jdbcUrl = "jdbc:mysql://localhost:3306/users";
        String dbUsername = "root";
        String dbPassword = "";

        try {
            // Chargement du pilote JDBC
            Class.forName("com.mysql.jdbc.Driver");

            // Connexion à la base de données
            conn = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword);

            // Insertion des données dans la base de données
            String sql = "INSERT INTO users (username, password, profession) VALUES (?, ?, ?)";
            statement = conn.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);
            statement.setString(3, profession);
            statement.executeUpdate();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                // Fermeture des ressources
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        String profession1 = request.getParameter("profession");

        if ("Administrateur".equals(profession1)) {
            // Redirection vers la page de tableau de bord de l'administrateur
            response.sendRedirect("Dashboard.html");
        } else {
            // Redirection vers la page d'accueil
            response.sendRedirect("login.html");
        }
}} 