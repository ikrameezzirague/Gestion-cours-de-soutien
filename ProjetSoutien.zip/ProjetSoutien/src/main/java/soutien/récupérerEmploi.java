package soutien;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/emploi")
public class récupérerEmploi extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	List<Map<String, Object>> primaireList = getPrimaireListFromDatabase();
        List<EmploiData> emploi1apicList = get1apicListFromDatabase();
        List<EmploiData> emploi2apicList = get2apicListFromDatabase();
        List<EmploiData> emploi3apicList = get3apicListFromDatabase();
        List<EmploiData> emploitrList = gettrListFromDatabase();
        List<EmploiData> emploi1bacList = get1bacListFromDatabase();
        List<EmploiData> emploiBacList = getBacListFromDatabase();


        request.setAttribute("primaireList", primaireList);
        request.setAttribute("emploi1apicList", emploi1apicList);
        request.setAttribute("emploi2apicList", emploi2apicList);
        request.setAttribute("emploi3apicList", emploi3apicList);
        request.setAttribute("emploitrList", emploitrList);
        request.setAttribute("emploi1bacList", emploi1bacList);
        request.setAttribute("emploiBacList", emploiBacList);
     

        request.getRequestDispatcher("emploi.jsp").forward(request, response);
    }

    public List<Map<String, Object>> getPrimaireListFromDatabase() {
        List<Map<String, Object>> primaireList = new ArrayList<>();

        String url = "jdbc:mysql://localhost:3306/users";
        String utilisateurBD = "root";
        String motDePasseBD = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            try (Connection connexion = DriverManager.getConnection(url, utilisateurBD, motDePasseBD);
                 java.sql.Statement statement = connexion.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM primaire")) {

                while (resultSet.next()) {
                    Map<String, Object> primaire = new HashMap<>();
                    primaire.put("id", resultSet.getInt("id"));
                    primaire.put("day", resultSet.getString("day"));
                    primaire.put("date", resultSet.getString("date"));
                    primaire.put("time", resultSet.getString("time"));
                    primaire.put("subject", resultSet.getString("subject"));
                    primaire.put("teacher", resultSet.getString("teacher"));
                    primaire.put("salle", resultSet.getString("salle"));

                    primaireList.add(primaire);
                    System.out.println(primaire); // Afficher chaque élément dans la console
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return primaireList;
    }
    

    public List<EmploiData> get1apicListFromDatabase() {
        List<EmploiData> emploiList = new ArrayList<>();

        String url = "jdbc:mysql://localhost:3306/users";
        String utilisateurBD = "root";
        String motDePasseBD = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            try (Connection connexion = DriverManager.getConnection(url, utilisateurBD, motDePasseBD);
                 java.sql.Statement statement = connexion.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM 1apic_table")) {

                while (resultSet.next()) {
                    EmploiData emploi = new EmploiData();
                    emploi.setDay(resultSet.getString("day"));
                    emploi.setDate(resultSet.getString("date"));
                    emploi.setTime(resultSet.getString("time"));
                    emploi.setSubject(resultSet.getString("subject"));
                    emploi.setTeacher(resultSet.getString("teacher"));
                    emploi.setRoom(resultSet.getString("room"));

                    emploiList.add(emploi);
                    System.out.println(emploi); // Afficher chaque élément dans la console
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return emploiList;
    }
    public List<EmploiData> get2apicListFromDatabase() {
        List<EmploiData> emploiList = new ArrayList<>();

        String url = "jdbc:mysql://localhost:3306/users";
        String utilisateurBD = "root";
        String motDePasseBD = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            try (Connection connexion = DriverManager.getConnection(url, utilisateurBD, motDePasseBD);
                 java.sql.Statement statement = connexion.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM 2apic_table")) {

                while (resultSet.next()) {
                    EmploiData emploi = new EmploiData();
                    emploi.setDay(resultSet.getString("day"));
                    emploi.setDate(resultSet.getString("date"));
                    emploi.setTime(resultSet.getString("time"));
                    emploi.setSubject(resultSet.getString("subject"));
                    emploi.setTeacher(resultSet.getString("teacher"));
                    emploi.setRoom(resultSet.getString("room"));

                    emploiList.add(emploi);
                    System.out.println(emploi); // Afficher chaque élément dans la console
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return emploiList;
    }
    public List<EmploiData> get3apicListFromDatabase() {
        List<EmploiData> emploiList = new ArrayList<>();

        String url = "jdbc:mysql://localhost:3306/users";
        String utilisateurBD = "root";
        String motDePasseBD = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            try (Connection connexion = DriverManager.getConnection(url, utilisateurBD, motDePasseBD);
                 java.sql.Statement statement = connexion.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM 3apic_table")) {

                while (resultSet.next()) {
                    EmploiData emploi = new EmploiData();
                    emploi.setDay(resultSet.getString("day"));
                    emploi.setDate(resultSet.getString("date"));
                    emploi.setTime(resultSet.getString("time"));
                    emploi.setSubject(resultSet.getString("subject"));
                    emploi.setTeacher(resultSet.getString("teacher"));
                    emploi.setRoom(resultSet.getString("room"));

                    emploiList.add(emploi);
                    System.out.println(emploi); // Afficher chaque élément dans la console
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return emploiList;
    }
    public List<EmploiData> gettrListFromDatabase() {
        List<EmploiData> emploiList = new ArrayList<>();

        String url = "jdbc:mysql://localhost:3306/users";
        String utilisateurBD = "root";
        String motDePasseBD = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            try (Connection connexion = DriverManager.getConnection(url, utilisateurBD, motDePasseBD);
                 java.sql.Statement statement = connexion.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM tronc_commun")) {

                while (resultSet.next()) {
                    EmploiData emploi = new EmploiData();
                    emploi.setDay(resultSet.getString("day"));
                    emploi.setDate(resultSet.getString("date"));
                    emploi.setTime(resultSet.getString("time"));
                    emploi.setSubject(resultSet.getString("subject"));
                    emploi.setTeacher(resultSet.getString("teacher"));
                    emploi.setRoom(resultSet.getString("room"));

                    emploiList.add(emploi);
                    System.out.println(emploi); // Afficher chaque élément dans la console
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return emploiList;
    }
    public List<EmploiData> get1bacListFromDatabase() {
        List<EmploiData> emploiList = new ArrayList<>();

        String url = "jdbc:mysql://localhost:3306/users";
        String utilisateurBD = "root";
        String motDePasseBD = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            try (Connection connexion = DriverManager.getConnection(url, utilisateurBD, motDePasseBD);
                 java.sql.Statement statement = connexion.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM 1bac")) {

                while (resultSet.next()) {
                    EmploiData emploi = new EmploiData();
                    emploi.setDay(resultSet.getString("day"));
                    emploi.setDate(resultSet.getString("date"));
                    emploi.setTime(resultSet.getString("time"));
                    emploi.setSubject(resultSet.getString("subject"));
                    emploi.setTeacher(resultSet.getString("teacher"));
                    emploi.setRoom(resultSet.getString("room"));

                    emploiList.add(emploi);
                    System.out.println(emploi); // Afficher chaque élément dans la console
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return emploiList;
    }
    public List<EmploiData> getBacListFromDatabase() {
        List<EmploiData> emploiList = new ArrayList<>();

        String url = "jdbc:mysql://localhost:3306/users";
        String utilisateurBD = "root";
        String motDePasseBD = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");

            try (Connection connexion = DriverManager.getConnection(url, utilisateurBD, motDePasseBD);
                 java.sql.Statement statement = connexion.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM bac")) {

                while (resultSet.next()) {
                    EmploiData emploi = new EmploiData();
                    emploi.setDay(resultSet.getString("day"));
                    emploi.setDate(resultSet.getString("date"));
                    emploi.setTime(resultSet.getString("time"));
                    emploi.setSubject(resultSet.getString("subject"));
                    emploi.setTeacher(resultSet.getString("teacher"));
                    emploi.setRoom(resultSet.getString("room"));

                    emploiList.add(emploi);
                    System.out.println(emploi); // Afficher chaque élément dans la console
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return emploiList;
    }
}


